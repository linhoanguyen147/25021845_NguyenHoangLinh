class Animal {
    public void makeSound() {
        System.out.println("Animal sound");
    }
}
class Dog extends Animal {
    @Override
    public void makeSound() {
        System.out.println("Woof woof");
    }
}
class Cat extends Animal {
    @Override
    public void makeSound() {
        System.out.println("Meows meows");
    }
}
class Duck extends Animal {
    
}
public class Main {
    public static void main(String[] args) {
        // Bước 1: Upcasting (An toàn)
        Animal a = new Dog(); // Dog kế thừa Animal (lấy từ Bài 2)
        // Bước 2: Downcasting (Rủi ro) - Hãy viết dòng này:
        // Cat c = (Cat) a; //ClassCastException error here
        // // Bước 3: Gọi hàm
        // c.makeSound();
        Cat c;
        if (a instanceof Cat){
            c = (Cat) a;
        }
        else{
            System.out.println("Day khong phai la Meo");
        }

    }
}
//javac bien dich thanh cong a co kieu Animal, tham chieu den vung nho
//neu Dog, sau do cast ve Cat (Cat la dan xuat cua Animal nen trinh bien dich
//se chap nhan viec ep cha ve con)
//java chay loi vi Cat va Dog co vai tro tuong duong (anh em)