class Person {
    protected String name;
    protected String dob;
    // public Person() {
    //     System.out.println("1. Person is created");
    // }
    public Person(String name) {
        this.name = name;
        System.out.println("1. Person is created");
    }
}
//first "hidden line" at top of every subclass: super() -> no-para parent's constr
//del constr -> no more Person() -> constrs below try to call Person() (super())
class Employee extends Person {
    protected double salary;
    public Employee() {
        super("I lost my identity card");
        System.out.println("2. Employee is created");
    }
}
class Manager extends Employee {
    protected String department;
    public Manager() {
        System.out.println("3. Manager is created");
    }
}
public class Main {
    public static void main(String[] args) {
        Manager m = new Manager();
    }
}
