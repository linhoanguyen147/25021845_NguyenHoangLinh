import java.util.Scanner;
abstract class Employee {
    protected String name, birthday, id;
    public Employee(String name) {
        this.name = name;
    }
    public String getName() {
        return name;
    }
    public abstract double calcSal();
    public abstract String getType();
}
class FullTimeEmployee extends Employee {
    protected double baseSalary, bonus, penalty;
    public FullTimeEmployee(String name, double baseSalary, double bonus, double penalty) {
        super(name);
        this.baseSalary = baseSalary;
        this.bonus = bonus;
        this.penalty = penalty;
    }
    public double calcSal() {
        return baseSalary + bonus - penalty;
    }
    public String getType() {
        return "Full-time";
    }
}
class PartTimeEmployee extends Employee {
    protected double workingHours, hourlyRate;
    public PartTimeEmployee(String name, double workingHours, double hourlyRate) {
        super(name);
        this.workingHours = workingHours;
        this.hourlyRate = hourlyRate;
    }
    public double calcSal() {
        return workingHours * hourlyRate;
    }
    public String getType() {
        return "Part-time";
    }
}
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        //System.out.println("Nhap so luong nhan vien: ");
        int n = sc.nextInt();
        sc.nextLine();
        Employee[] e = new Employee[n];
        for (int i = 0; i < n; ++i) {
            String inp = sc.nextLine();
            String[] a = inp.trim().split("\\s+");
            int m = a.length;
            String name = "";
            if (inp.charAt(0) == 'F') {
                for (int j = 1; j < m - 3; ++j) {
                    for (char c: a[j].toCharArray()) if (c != '"') name += c;
                    name += ' ';
                }
                e[i] = new FullTimeEmployee(name.trim(), Double.parseDouble(a[m - 3]), Double.parseDouble(a[m - 2]), Double.parseDouble(a[m - 1]));
            }
            else {
                for (int j = 1; j < m - 2; ++j) {
                    for (char c: a[j].toCharArray()) if (c != '"') name += c;
                    name += ' ';
                }
                e[i] = new PartTimeEmployee(name.trim(), Double.parseDouble(a[m - 2]), Double.parseDouble(a[m - 1]));
            }
        }
        for (int i = 0; i < n; ++i) {
            System.out.println((e[i].getName()) + " - " + e[i].getType() + " - " + e[i].calcSal());
        }
    }
}
