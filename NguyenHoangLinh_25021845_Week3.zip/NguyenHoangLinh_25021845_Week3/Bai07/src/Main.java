import java.util.Scanner;
class Room {
    protected long price;
    protected int nightCount;
    public Room() {}
    public Room(long price, int nightCount) {
        this.price = price;
        this.nightCount = nightCount;
    }
    public void setPrice(long price) {
        this.price = price;
    }
    public void setNightCount(int nightCount) {
        this.nightCount = nightCount;
    }
    public int getNightCount() {
        return nightCount;
    }
    public long getPrice() {
        return price;
    }
}
class Standard extends Room {
    public Standard(long price, int nightCount) {
        super(price, nightCount);
    }
    public long finalPrice() {
        return nightCount > 3 ? price * nightCount / 100 * 95 : price * nightCount;
    }
}
class VIP extends Room {    
    public VIP(long price, int nightCount) {
        super(price, nightCount);
    }
    public long finalPrice() {
        return price * nightCount;
    }
}
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String inp = sc.nextLine();
        char t = inp.charAt(0);
        int cnt = Integer.parseInt(inp.substring(1).trim());
        if (t == 'S') {
            Standard r = new Standard(500000, cnt);
            System.out.println(r.finalPrice());
        }
        else {
            VIP r = new VIP(2000000, cnt);
            System.out.println(r.finalPrice());
        }
    }
}
