import java.time.LocalDate;
import java.util.Scanner;
class Product {
    protected String id, name;
    protected double price;
    public Product(String n, double pr) {
        name = n;
        price = pr;
    }
    public double getFinalPrice() {
        return price;
    }
    public String getName() {
        return name;
    }
    public String getType() {
        return "Product";
    }
}
class Electronics extends Product {
    protected double fee;
    public Electronics(String n, double pr, double f) {
        super(n, pr);
        fee = f;
    }
    public double getFinalPrice() {
        return price * 1.1 + fee;
    }
    public String getType() {
        return "Electronics";
    }
}
class Food extends Product {
    protected LocalDate exp;
    public Food(String n, double pr, LocalDate e) {
        super(n, pr);
        exp = e;
    }
    public double getFinalPrice() {
        return exp.toEpochDay() - LocalDate.now().toEpochDay() < 7 ? 0.8 * price : price;
    }
    public String getType() {
        return "Food";
    }
}
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt(); sc.nextLine();
        Product[] p = new Product[n];
        for (int i = 0; i < n; ++i) {
            String inp = sc.nextLine().trim();
            String[] a = inp.split("\\s+");
            String name = "";
            for (int j = 1; j < a.length - 2; ++j) {
                name += a[j].replace("\"", "");
                name += " ";
            }
            if (inp.charAt(i) == 'E') p[i] = new Electronics(name.trim(), Double.parseDouble(a[a.length - 2]), Double.parseDouble(a[a.length - 1]));
            else p[i] = new Food(name.trim(), Double.parseDouble(a[a.length - 2]), LocalDate.parse(a[a.length - 1]));
        }
        double s = 0;
        for (int i = 0; i < n; ++i) {
            s += p[i].getFinalPrice();
            System.out.println(p[i].getName() + " - " + p[i].getType() + " - " + p[i].getFinalPrice());
        }
        System.out.println("Total = " + (s));
    }
}


