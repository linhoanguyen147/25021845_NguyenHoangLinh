import java.util.Scanner;
abstract class Robot {
    private int id, batteryLevel;
    private String modelName;
    public Robot(int id, String modelName) {
        this.id = id;
        this.modelName = modelName;
        this.batteryLevel = 0;
    }
    public int getId() {
        return id;
    }
    public String getName() {
        return modelName;
    }
    public final void showIdentity() {
        System.out.println((id) + " - " + (modelName));
    }
    public void chargeBattery() {
        batteryLevel = 100;
    }
    public abstract void performMainTask();
}
interface Flyable {
    void fly();
}
interface Swimmable {
    void swim();
}
interface GPS {
    void getCoordinates();
}
class DroneRobot extends Robot implements Flyable, GPS {
    public DroneRobot(int id, String name) {
        super(id, name);
    }
    public void performMainTask() {
        System.out.println((super.getName()) + " performing main task");
    }
    public void fly() {
        System.out.println((super.getName()) + " flying");
    }
    public void getCoordinates() {
        System.out.println((super.getName()) + " getting coordinates");
    }
}
class FishRobot extends Robot implements Swimmable {
    public FishRobot(int id, String name) {
        super(id, name);
    }
    public void performMainTask() {
        System.out.println((super.getName()) + " performing main task");
    }
    public void swim() {
        System.out.println((super.getName()) + " swimming");
    }
}
class AmphibiousRobot extends Robot implements Flyable, Swimmable, GPS {
    public AmphibiousRobot(int id, String name) {
        super(id, name);
    }
    public void performMainTask() {
        System.out.println((super.getName()) + " performing main task");
    }
    public void fly() {
        System.out.println((super.getName()) + " flying");
    }
    public void getCoordinates() {
        System.out.println((super.getName()) + " getting coordinates");
    }
    public void swim() {
        System.out.println((super.getName()) + " swimming");
    }
}
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        Robot[] a = new Robot[n];
        for (int i = 0; i < n; ++i) {
            String t = sc.next().trim();
            int id = sc.nextInt();
            String name = sc.next().trim();
            if (t.equals("DR")) a[i] = new DroneRobot(id, name);
            else if (t.equals("FR")) a[i] = new FishRobot(id, name);
            else a[i] = new AmphibiousRobot(id, name);
        }
        for (int i = 0; i < n; ++i) {
            a[i].performMainTask();
            if (a[i] instanceof Flyable) ((Flyable)a[i]).fly();
            if (a[i] instanceof Swimmable) ((Swimmable)a[i]).swim();
            if (a[i] instanceof GPS) ((GPS)a[i]).getCoordinates();
        }
    }
}
