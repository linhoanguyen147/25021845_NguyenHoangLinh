class Animal {
    public void makeSound() {
        System.out.println("Animal sound");
    }
}
class Dog extends Animal {
    @Override
    public void makeSound() {
        System.out.println("Woof woof");
    }
}
class Cat extends Animal {
    @Override
    public void makeSound() {
        System.out.println("Meows meows");
    }
}
class Duck extends Animal {
    
}
public class Main {
    public static void main(String[] args) {
        Animal[] zoo = new Animal[4]; 
        zoo[0] = new Dog();//upcasting: Dog -> Animal
        zoo[1] = new Cat();
        zoo[2] = new Duck();
        zoo[3] = new Dog();
        //polymorphism
        for (int i = 0; i < 4; ++i) {
            zoo[i].makeSound();
        }
        //duck inherits makeSound() from Animal;
    }
}
