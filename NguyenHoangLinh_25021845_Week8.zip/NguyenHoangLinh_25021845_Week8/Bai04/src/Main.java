import java.util.*;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

class BookStore {
    private Map<String ,Integer> stock;
    private final ReadWriteLock lock = new ReentrantReadWriteLock();
    public BookStore() {
        stock = new HashMap<>();
    }
    public int getStock(String title) {
        lock.readLock().lock();
        try {
            System.out.println(Thread.currentThread().getName() + " dang doc " + stock.getOrDefault(title, 0) + " sach " + title);
            return stock.getOrDefault(title, 0);
        }
        finally {
            lock.readLock().unlock();
        }
    }
    public void addBook(String title, int qty) {
        lock.writeLock().lock();
        try {
            System.out.println(Thread.currentThread().getName() + " dang them " + qty + " sach " + title);
            stock.put(title, stock.getOrDefault(title, 0) + qty);
        }
        finally {
            lock.writeLock().unlock();
        }
    }
    public void borrow(String title, int qty) {
        lock.writeLock().lock();
        try {
            if (stock.getOrDefault(title, 0) >= qty) {
                System.out.println(Thread.currentThread().getName() + " dang muon " + qty + " sach " + title);
                stock.replace(title,stock.getOrDefault(title, 0) - qty);
            }
            else System.out.println(Thread.currentThread().getName() + " khong muon duoc, chi con " + stock.getOrDefault(title, 0) + " sach " + title);
        }
        finally {
            lock.writeLock().unlock();
        }
    }
}
public class Main {
    public static void main(String[] args) {
        BookStore b = new BookStore();
        b.addBook("harry potter", 5);
        b.addBook("sherlock holmes", 4);
        Thread r1 = new Thread(() -> {
            b.getStock("harry potter");
        }, "r1");
        Thread r2 = new Thread(() -> {
            b.getStock("harry potter");
        }, "r2");
        Thread r3 = new Thread(() -> {
            b.getStock("harry potter");
        }, "r3");
        Thread w1 = new Thread(() -> {
            b.addBook("harry potter", 10);
        }, "w1");
        Thread w2 = new Thread(() -> {
            b.borrow("harry potter", 15);
        }, "w2");
        r1.start();
        r2.start();
        w1.start();
        r3.start();
        w2.start();
    }
}
