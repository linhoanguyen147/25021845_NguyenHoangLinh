import java.util.HashMap;
import java.util.Map;
/*
vi pham SRP. có quá nhiều chức năng
    find: truy xuất
    send: gửi
    render: xử lý
    export: xuất
nếu sửa logic nào đó cần động vào cả class này, dễ phát sinh lỗi chéo
-> extract class refactor, tách thành các lớp nhỏ, mỗi lớp một nhiệm vụ
 */
public class UserService {

//    public User findById(int id) {}
//    public void sendWelcomeEmail(User user) {  }
//    public void sendPasswordResetEmail(User user) {  }
//    public void renderUserProfile(User user) {  }
//    public String exportUserToCsv(User user) { }

    private UserService instance;
    private Map<String, User> users;
    private UserService() {
        users = new HashMap<>();
    }
    public UserService getInstance() {
        if (instance == null) instance = new UserService();
        return instance;
    }
    public User findById(int id) {
        return users.get(Integer.toString(id));
    }
}

