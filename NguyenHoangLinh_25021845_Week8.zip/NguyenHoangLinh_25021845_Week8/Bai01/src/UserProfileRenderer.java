public class UserProfileRenderer {
    public void renderUserProfile(User user) {

    }
}
