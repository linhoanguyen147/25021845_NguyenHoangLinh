public class Rectangle extends Shape{
    private double a, b; //2 canh
    public Rectangle(double a, double b) {
        this.a = a;
        this.b = b;
    }

    @Override
    public double getArea() { return a * b; }
}
