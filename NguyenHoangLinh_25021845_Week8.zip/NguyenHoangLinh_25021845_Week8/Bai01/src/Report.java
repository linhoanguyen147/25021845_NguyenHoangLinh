//các nhóm dữ liệu liên quan nhau xuất hiện lẻ tẻ
//extract class refactor gom nhóm Author lại
public class Report {
    private String title;
    private String content;
//    private String authorEmail;
//    private String authorName;
//    private String authorPhone;
//    private String authorAddress;
}

