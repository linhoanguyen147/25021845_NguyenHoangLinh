/*
dùng if-else quá nhiều, sử dụng trực tiếp 3.14159 (số PI)
-> áp dụng replace conditional with polymorphism:
    Shape gồm Rectangle, Triangle, Circle
 */
public abstract class Shape {
//    public double getArea(String shapeType, double a, double b) {
//        if (shapeType.equals("rectangle")) return a * b;
//        if (shapeType.equals("triangle"))  return 0.5 * a * b;
//        if (shapeType.equals("circle"))    return 3.14159 * a * a;
//        return -1;
//    }
    public abstract double getArea();
}
