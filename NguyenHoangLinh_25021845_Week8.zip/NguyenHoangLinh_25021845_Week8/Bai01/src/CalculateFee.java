//ten bien ko ro rang, qua ngan gon, co the hieu h: hours, r: rate, m: has discount
//san pham co the duoc giam 10% gia -> constant 0.9
//-> refactor: rename variable/method và replace with constant
public class CalculateFee {
    private static final double DISCOUNT = 0.9;
    public double calculateFee(int hours, double rate, boolean hasDiscount) { //thua tham so kieu string khong dung
        double total = rate * hours;
        return hasDiscount ? total * DISCOUNT : total;
    }
}
