public class Triangle extends Shape {
    private double canhday, chieucao;
    public Triangle(double canhday, double chieucao) {
        this.canhday = canhday;
        this.chieucao = chieucao;
    }

    @Override
    public double getArea() {
        return 0.5 * canhday * chieucao;
    }
}
