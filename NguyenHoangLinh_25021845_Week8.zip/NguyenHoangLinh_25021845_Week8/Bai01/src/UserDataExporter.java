public class UserDataExporter {
    public String exportUserToCsv(User user) {
        return "User: " + user.getId();
    }
}
