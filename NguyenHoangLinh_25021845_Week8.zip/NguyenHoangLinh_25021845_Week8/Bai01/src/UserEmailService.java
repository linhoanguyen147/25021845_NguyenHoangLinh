public class UserEmailService  {
    public void sendWelcomeEmail(User user) {
        //
    }
    public void sendPasswordResetEmail(User user) {
        //
    }
}
