public class Author {
    private String email;
    private String name;
    private String phone;
    private String address;
}
