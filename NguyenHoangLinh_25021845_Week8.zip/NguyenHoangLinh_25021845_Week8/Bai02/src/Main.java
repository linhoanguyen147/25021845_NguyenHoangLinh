import java.util.*;
import java.util.concurrent.*;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] a = new int[n];
        for (int i = 0; i < n; ++i) a[i] = sc.nextInt();
        int k = 4;
        int len = n % k == 0 ? n / k : n / k + 1;
        ExecutorService es = Executors.newFixedThreadPool(k);
        List<Future<Integer>> f = new ArrayList<>();
        for (int i = 0; i < k; ++i) {
            int l = i * len;
            int r = Math.min(l + len, n);
            Callable<Integer> calc = () -> {
                int res = 0;
                for (int j = l; j < r; ++j) res += a[j];
                return res;
            };
            f.add(es.submit(calc));
        }
        int res = 0;
        for (Future<Integer> x: f) {
            try {
                res += x.get();
            }
            catch (Exception e) {}
        }
        System.out.println(res);
        es.shutdown();
        sc.close();
    }
}