import java.util.concurrent.locks.ReentrantLock;

class Counter {
    private int value;
    private final ReentrantLock lock = new ReentrantLock();
    public Counter(int v) {
        value = v;
    }
    public void increment() {
        lock.lock();
        try {
            ++value;
        }
        finally {
            lock.unlock();
        }
    }
    public void incrementWithTryLock() {
        if (lock.tryLock()) {
            try {
                ++value;
            }
            finally {
                lock.unlock();
            }
        }
        else System.out.println("khong lay duoc lock");
    }
    public int getValue() {
        return value;
    }
}
public class Main {
    public static void main(String[] args) {
        Counter cnt = new Counter(0);
        Runnable r = () -> {
            for (int i = 0; i < 10000; ++i) cnt.increment();
        };
        Thread a = new Thread(r);
        Thread b = new Thread(r);
        Thread c = new Thread(r);
        Thread d = new Thread(r);
        a.start();
        b.start();
        c.start();
        d.start();
        try {
            a.join();
            b.join();
            c.join();
            d.join();
        } catch (InterruptedException e) {}
        System.out.println("increment: " + cnt.getValue());
        r = () -> {
            for (int i = 0; i < 10000; ++i) cnt.incrementWithTryLock();
        };
        a = new Thread(r);
        b = new Thread(r);
        c = new Thread(r);
        d = new Thread(r);
        a.start();
        b.start();
        c.start();
        d.start();
        try {
            a.join();
            b.join();
            c.join();
            d.join();
        } catch (InterruptedException e) {}
        System.out.println("increment with tryLock(): " + cnt.getValue());
    }
}
