import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ExecutorService es = Executors.newFixedThreadPool(10);
        List<Future<Integer>> f = new ArrayList<>();
        int n = sc.nextInt();
        for (int i = 0; i < n; ++i) {
            int m = sc.nextInt();
            int[] a = new int[m];
            for (int j = 0; j < m; ++j) a[j] = sc.nextInt();
            Callable<Integer> c = () -> {
                int res = 0;
                for (int j = 0; j < m; ++j) {
                    if (a[j] <= 1) continue;
                    boolean pr = true;
                    for (int x = 2; x * x <= a[j] && pr; ++x) if (a[j] % x == 0) pr = false;
                    res += pr ? 1 : 0;
                }
                return res;
            };
            f.add(es.submit(c));
        }
        int mx = 0;
        for (int i = 0; i < n; ++i) {
            try {
                int k = f.get(i).get();
                mx = Math.max(mx, k);
                System.out.println("Array " + i + ": " + k);
            }
            catch(Exception e) {}
        }
        System.out.print("Most primes: ");
        ArrayList<Integer> b = new ArrayList<>();
        for (int i = 0; i < n; ++i) {
            try {
                if (f.get(i).get() == mx) b.add(i);
            }
            catch(Exception e) {}
        }
        for (int i = 0; i < b.size(); ++i) {
            System.out.print("Array " + b.get(i));
            if (i < b.size() - 1) System.out.print(", ");
            else System.out.print(" ");
        }
        System.out.println("with " + mx + " primes");
        es.shutdown();
        sc.close();
    }
}

