import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Main {
    public static boolean isprime(int x) {
        if (x <= 1) return false;
        for (int i = 2; i * i <= x; ++i) if (x % i == 0) return false;
        return true;
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        ExecutorService es1 = Executors.newFixedThreadPool(10);
        ExecutorService es2 = Executors.newFixedThreadPool(10);
        List<CompletableFuture<Long>> cfs = new ArrayList<>();
        for (int i = 0; i < n; ++i) {
            int m = sc.nextInt();
            int[] a = new int[m];
            for (int j = 0; j < m; ++j) a[j] = sc.nextInt();
            final int id = i;
            CompletableFuture<Long> cf = CompletableFuture.supplyAsync(() -> {
                List<Integer> pr = new ArrayList<>();
                for (int x: a) if (isprime(x)) pr.add(x);
                return pr;
            }, es1).thenApply(pr -> {
                System.out.println("Stage 1 - Array " + id + ": " + pr);
                return pr;
            }).thenApplyAsync(pr -> {
                long res = 0;
                for (int p: pr) res += pr.size() % 2 == 0 ? (long) p * p : (long) p * p * p;
                System.out.println("Stage 2 - Array " + id + ": sum of " + (pr.size() % 2 == 0 ? "squares" : "cubes") + " = " + res);
                return res;
            }, es2);
            cfs.add(cf);
        }
        CompletableFuture<Void> all = CompletableFuture.allOf(cfs.toArray(new CompletableFuture[0]));
        all.join();
        long res = 0;
        for (CompletableFuture<Long> x: cfs) {
            try {
                res += x.get();
            }
            catch (Exception e) {}
        }
        System.out.println("Total = " + res);
        es1.shutdown();
        es2.shutdown();
        sc.close();
    }
}

