import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class Ex5Test {
    @Test
    public void test() {
        assertEquals("SUNDAY", Ex5.getDay(4, 1, 2007));
        assertEquals("THURSDAY", Ex5.getDay(2, 29, 2024));
        assertEquals("SATURDAY", Ex5.getDay(1, 1, 2000));
    }
}
