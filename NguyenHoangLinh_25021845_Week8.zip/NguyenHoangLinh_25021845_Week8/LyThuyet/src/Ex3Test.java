import org.junit.Test;

import static org.junit.jupiter.api.Assertions.*;

public class Ex3Test {
    @Test
    public void testOperations() {
        assertEquals("12345678901234567890", Ex3.add("12345678900000000000", "1234567890"));
        assertEquals("0", Ex3.multiply("999999999999999999", "0"));
        assertEquals("-50", Ex3.add("-100", "50"));
    }
}
