ư

public class MathUtilsTest {
    @Test
    public void testMax() {
        assertEquals(5, MathUtils.max(5, -1));
        assertEquals(4, MathUtils.max(1, 4));
        assertEquals(100, MathUtils.max(100, 100));

        int mx = Integer.MAX_VALUE;
        int mn = Integer.MIN_VALUE;
        assertEquals(mx, MathUtils.max(mx, mn));
        assertEquals(mx, MathUtils.max(mn, mx));
        assertEquals(mx, MathUtils.max(mx, mx));
        assertEquals(mn, MathUtils.max(mn, mn));
        assertEquals(0, MathUtils.max(0, mn));
    }
    @Test
    public void testDivide() {
        assertEquals(2, MathUtils.divide(10, 5));
        assertEquals(-27, MathUtils.divide(-81, 3));
        assertEquals(9, MathUtils.divide(-81, -9));
        assertEquals(0, MathUtils.divide(0, Integer.MAX_VALUE));
        assertEquals(0, MathUtils.divide(0, Integer.MIN_VALUE));
    }
    @Test
    public void testDivideByZero() {
        assertThrows(IllegalArgumentException.class, () -> MathUtils.divide(100, 0));
    }
}
