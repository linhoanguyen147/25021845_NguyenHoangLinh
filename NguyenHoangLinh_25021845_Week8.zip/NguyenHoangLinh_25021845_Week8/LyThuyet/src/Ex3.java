import java.math.BigInteger;

public class Ex3 {
    public static String add(String a, String b) {
        return new BigInteger(a).add(new BigInteger(b)).toString();
    }

    public static String multiply(String a, String b) {
        return new BigInteger(a).multiply(new BigInteger(b)).toString();
    }
}
