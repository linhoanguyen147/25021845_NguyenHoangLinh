import java.time.LocalDateTime;
import java.time.LocalDate;

public class Ex5 {
    public static String getDay(int m, int d, int y) {
        return LocalDate.of(y, m, d).getDayOfWeek().name();
    }
}
