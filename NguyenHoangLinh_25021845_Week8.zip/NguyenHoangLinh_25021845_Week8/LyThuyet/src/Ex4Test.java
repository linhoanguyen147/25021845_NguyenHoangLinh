import org.junit.Test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class Ex4Test {
    @Test
    public void test() {
        assertTrue(Ex4.check("{}()"));
        assertTrue(Ex4.check("({[]})"));
        
        assertFalse(Ex4.check("{}("));
        assertFalse(Ex4.check("({[}])")); // Lệch thứ tự
        
        assertTrue(Ex4.check(""));
        assertFalse(Ex4.check("}"));
    }
}
