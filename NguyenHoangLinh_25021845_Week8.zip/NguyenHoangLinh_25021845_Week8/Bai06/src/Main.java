import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class Main {
    public static Integer find(int[] a) {
        if (a == null || a.length <= 1) return null;
        Integer fi = null, se = null;
        for (int x: a) {
            if (fi == null || fi < x) {
                se = fi;
                fi = x;
            }
            else if (fi > x && (se == null || se < x)) se = x;
        }
        return se;
    }
    public static void main(String[] args) {
        ExecutorService es = Executors.newFixedThreadPool(10);
        List<Future<Integer>> f = new ArrayList<>();
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        for (int i = 0; i < n; ++i) {
            int m = sc.nextInt();
            int[] a = new int[m];
            for (int j = 0; j < m; ++j) a[j] = sc.nextInt();
            f.add(es.submit(() -> find(a)));
        }
        int res = 0;
        for (int i = 0; i < n; ++i) {
            try {
                Integer k = f.get(i).get();
                if (k != null) {
                    res += k;
                    System.out.println("Array " + i + ": second largest = " + k);
                }
                else System.out.println("Array " + i + ": Not found");
            }
            catch(Exception e) {}
        }
        System.out.println("Sum = " + res);
        es.shutdown();
        sc.close();
    }
}


