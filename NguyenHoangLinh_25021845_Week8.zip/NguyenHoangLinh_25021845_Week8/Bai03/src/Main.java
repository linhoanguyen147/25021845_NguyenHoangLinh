class BankAccount {
    private volatile int balance;
    public BankAccount(int balance) {
        this.balance = balance;
    }
    public synchronized void deposit(int amount) {
        balance += amount;
    }
    public synchronized void withdraw(int amount) {
        balance -= amount;
    }
    public int getBalance() {
        return balance;
    }
}
public class Main {
    public static void main(String[] args) {
        BankAccount acc = new BankAccount(0);
        Thread a = new Thread(() -> {
            for (int i = 1; i <= 1000; ++i) acc.deposit(100);
        });
        Thread b = new Thread(() -> {
            for (int i = 1; i <= 1000; ++i) acc.withdraw(100);
        });
        a.start();
        b.start();
        try {
            a.join();
            b.join();
        }
        catch (InterruptedException e) {}
        System.out.println(acc.getBalance());
    }
}
