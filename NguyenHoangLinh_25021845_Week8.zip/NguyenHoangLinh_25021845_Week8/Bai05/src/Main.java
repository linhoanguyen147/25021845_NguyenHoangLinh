import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicInteger;

public class Main {
    public static void main(String[] args) {
        ExecutorService es = Executors.newFixedThreadPool(10);
        Scanner sc = new Scanner(System.in);
        int m = sc.nextInt();
        List<String> logs = new ArrayList<>();
        AtomicInteger cnt = new AtomicInteger(0);
        List<Future<Boolean>> f = new ArrayList<>();
        for (int i = 0; i < m; ++i) {
            String id = sc.next();
            long processMs = sc.nextLong();
            Callable<Boolean> c = () -> {
                System.out.println("Start " + id);
                try {
                    Thread.sleep(processMs);
                }
                catch(InterruptedException e) {
                    Thread.currentThread().interrupt();
                    return false;
                }
                synchronized (logs) {
                    logs.add(processMs > 1500 ? "FAIL " + id : "DONE " + id);
                }
                if (processMs <= 1500) {
                    cnt.incrementAndGet();
                    return true;
                }
                return false;
            };
            f.add(es.submit(c));
        }
        for (Future<Boolean> x: f) {
            try {
                x.get();
            }
            catch (Exception e) {}
        }
        System.out.println("Success = " + cnt.get());
        for (String x: logs) System.out.println(x);
        es.shutdown();
        sc.close();
    }
}
