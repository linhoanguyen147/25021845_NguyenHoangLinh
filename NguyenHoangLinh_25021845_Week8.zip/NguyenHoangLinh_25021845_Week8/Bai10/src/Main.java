class Worker implements Runnable {
    private volatile boolean running = true;
    public void stop() {
        running = false;
    }
    @Override
    public void run() {
        while(running) {
            System.out.println("Working...");
        }
    }
}
public class Main {
    public static void main(String[] args) {
        Worker w = new Worker();
        Thread t = new Thread(w);
        t.start();
        try {
            Thread.sleep(1000);
        }catch (Exception e) {}
        w.stop();
        try {
            t.join();
        }
        catch (Exception e) {}
    }
}
//mỗi luồng (như main hay t chạy trên cpu core khác nhau, có vùng nhớ
//đệm cache riêng, nên nếu không có volatile thì luồng t sẽ copy biến
//running từ ram vào cache. khi main gọi stop(), ở ram running = false
//nhưng ngay lúc đó có thể t không biết việc đó vì vẫn đọc true ở cache
//dẫn đến program có thể lặp vô hạn
//có volatile s ép JVM bỏ qua cache và đọc/ghi thẳng trên ram

